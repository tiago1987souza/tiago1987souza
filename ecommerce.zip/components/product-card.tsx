import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Product } from "@/lib/types"
import { AddToCartButton } from "./add-to-cart-button"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const discountPercentage = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0

  return (
    <Card className="overflow-hidden group">
      <Link href={`/produtos/${product.id}`}>
        <div className="aspect-square overflow-hidden bg-muted relative">
          {product.oldPrice && (
            <Badge className="absolute top-2 left-2 z-10 bg-red-500 hover:bg-red-500">-{discountPercentage}%</Badge>
          )}
          {product.isNew && <Badge className="absolute top-2 right-2 z-10">Novo</Badge>}
          <img
            src={product.image || `/placeholder.svg?height=400&width=400&text=${product.name}`}
            alt={product.name}
            className="object-cover w-full h-full transition-transform group-hover:scale-105"
          />
        </div>
      </Link>
      <CardContent className="p-4">
        <div className="text-sm text-muted-foreground mb-1">{product.category}</div>
        <Link href={`/produtos/${product.id}`} className="hover:underline">
          <h3 className="font-medium line-clamp-1">{product.name}</h3>
        </Link>
        <div className="flex items-baseline gap-2 mt-2">
          <span className="font-bold">R$ {product.price.toFixed(2)}</span>
          {product.oldPrice && (
            <span className="text-sm text-muted-foreground line-through">R$ {product.oldPrice.toFixed(2)}</span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <AddToCartButton product={product} variant="outline" className="w-full" />
      </CardFooter>
    </Card>
  )
}

