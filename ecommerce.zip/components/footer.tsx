import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center space-x-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <circle cx="8" cy="21" r="1" />
                <circle cx="19" cy="21" r="1" />
                <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
              </svg>
              <span className="font-bold text-xl">LojaVirtual</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground">
              Sua loja online para encontrar os melhores produtos com os melhores preços.
            </p>
            <div className="flex gap-4 mt-6">
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-4">Categorias</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/categorias/eletronicos" className="text-muted-foreground hover:text-primary">
                  Eletrônicos
                </Link>
              </li>
              <li>
                <Link href="/categorias/moda" className="text-muted-foreground hover:text-primary">
                  Moda
                </Link>
              </li>
              <li>
                <Link href="/categorias/casa" className="text-muted-foreground hover:text-primary">
                  Casa
                </Link>
              </li>
              <li>
                <Link href="/categorias/esportes" className="text-muted-foreground hover:text-primary">
                  Esportes
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium mb-4">Informações</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/sobre" className="text-muted-foreground hover:text-primary">
                  Sobre nós
                </Link>
              </li>
              <li>
                <Link href="/politica-de-privacidade" className="text-muted-foreground hover:text-primary">
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link href="/termos-de-servico" className="text-muted-foreground hover:text-primary">
                  Termos de Serviço
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary">
                  Perguntas Frequentes
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium mb-4">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-muted-foreground">Rua Exemplo, 123</li>
              <li className="text-muted-foreground">São Paulo, SP</li>
              <li>
                <a href="tel:+551199999999" className="text-muted-foreground hover:text-primary">
                  +55 11 9999-9999
                </a>
              </li>
              <li>
                <a href="mailto:contato@lojavirtual.com" className="text-muted-foreground hover:text-primary">
                  contato@lojavirtual.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-6 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} LojaVirtual. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}

