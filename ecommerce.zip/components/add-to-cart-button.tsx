"use client"

import { Button, type ButtonProps } from "@/components/ui/button"
import { useCart } from "./cart-provider"
import type { Product } from "@/lib/types"
import { ShoppingCart } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/components/ui/use-toast"

interface AddToCartButtonProps extends ButtonProps {
  product: Product
}

export function AddToCartButton({ product, className, variant = "default", ...props }: AddToCartButtonProps) {
  const { addToCart } = useCart()
  const { toast } = useToast()

  const handleAddToCart = () => {
    addToCart(product)
    toast({
      title: "Produto adicionado",
      description: `${product.name} foi adicionado ao seu carrinho.`,
      duration: 3000,
    })
  }

  return (
    <Button onClick={handleAddToCart} className={cn(className)} variant={variant} {...props}>
      <ShoppingCart className="mr-2 h-4 w-4" />
      Adicionar ao carrinho
    </Button>
  )
}

