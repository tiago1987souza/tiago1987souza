"use client"

import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { Trash2, Minus, Plus, ArrowRight, ShoppingBag } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { Input } from "@/components/ui/input"

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart } = useCart()
  const [couponCode, setCouponCode] = useState("")

  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 200 ? 0 : 15
  const total = subtotal + shipping

  if (cart.length === 0) {
    return (
      <div className="container px-4 md:px-6 py-12 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center text-center max-w-md">
          <div className="bg-muted rounded-full p-6 mb-4">
            <ShoppingBag className="h-12 w-12 text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Seu carrinho está vazio</h1>
          <p className="text-muted-foreground mb-6">
            Parece que você ainda não adicionou nenhum produto ao seu carrinho. Explore nossa loja para encontrar
            produtos incríveis.
          </p>
          <Link href="/produtos">
            <Button>
              Continuar comprando
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container px-4 md:px-6 py-6 md:py-12">
      <h1 className="text-3xl font-bold mb-8">Seu Carrinho</h1>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="border rounded-lg overflow-hidden">
            <div className="bg-muted px-4 py-3 font-medium">
              <div className="grid grid-cols-12 gap-4">
                <div className="col-span-6">Produto</div>
                <div className="col-span-2 text-center">Preço</div>
                <div className="col-span-2 text-center">Quantidade</div>
                <div className="col-span-2 text-center">Total</div>
              </div>
            </div>

            <div className="divide-y">
              {cart.map((item) => (
                <div key={item.id} className="px-4 py-4">
                  <div className="grid grid-cols-12 gap-4 items-center">
                    <div className="col-span-6">
                      <div className="flex items-center gap-4">
                        <div className="h-16 w-16 rounded bg-muted flex-shrink-0 overflow-hidden">
                          <img
                            src={item.image || `/placeholder.svg?height=64&width=64&text=${item.name}`}
                            alt={item.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium">{item.name}</h3>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-sm text-red-500 flex items-center mt-1 hover:underline"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Remover
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="col-span-2 text-center">R$ {item.price.toFixed(2)}</div>
                    <div className="col-span-2">
                      <div className="flex items-center justify-center">
                        <button
                          onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="h-8 w-8 rounded-l border flex items-center justify-center hover:bg-muted"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <div className="h-8 w-10 border-t border-b flex items-center justify-center">
                          {item.quantity}
                        </div>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="h-8 w-8 rounded-r border flex items-center justify-center hover:bg-muted"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                    <div className="col-span-2 text-center font-medium">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between mt-6">
            <Link href="/produtos">
              <Button variant="outline">Continuar comprando</Button>
            </Link>
          </div>
        </div>

        <div>
          <div className="border rounded-lg p-6">
            <h2 className="text-lg font-bold mb-4">Resumo do Pedido</h2>

            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>R$ {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Frete</span>
                <span>{shipping === 0 ? "Grátis" : `R$ ${shipping.toFixed(2)}`}</span>
              </div>
              <div className="border-t pt-2 mt-2">
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>R$ {total.toFixed(2)}</span>
                </div>
                <div className="text-xs text-muted-foreground mt-1">Incluindo impostos</div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Código promocional"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                  />
                  <Button variant="outline" size="sm">
                    Aplicar
                  </Button>
                </div>
              </div>

              <Button className="w-full">Finalizar Compra</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

