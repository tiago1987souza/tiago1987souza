import { AddToCartButton } from "@/components/add-to-cart-button"
import { Button } from "@/components/ui/button"
import { getProductById, getRelatedProducts } from "@/lib/products"
import { ArrowLeft, Check, Truck } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ProductCard } from "@/components/product-card"

export default async function ProductPage({ params }: { params: { id: string } }) {
  const product = await getProductById(params.id)

  if (!product) {
    notFound()
  }

  const relatedProducts = await getRelatedProducts(product.category)

  return (
    <div className="container px-4 md:px-6 py-6 md:py-12">
      <Link href="/produtos" className="inline-flex items-center text-sm font-medium text-primary mb-6 hover:underline">
        <ArrowLeft className="mr-1 h-4 w-4" />
        Voltar para produtos
      </Link>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        {/* Product Image */}
        <div className="flex justify-center">
          <div className="relative aspect-square w-full max-w-[500px] overflow-hidden rounded-lg bg-muted">
            <img
              src={product.image || `/placeholder.svg?height=600&width=600&text=${product.name}`}
              alt={product.name}
              className="object-cover w-full h-full"
            />
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col gap-4">
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <p className="text-sm text-muted-foreground mt-2">Código: {product.id}</p>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">R$ {product.price.toFixed(2)}</span>
            {product.oldPrice && (
              <span className="text-muted-foreground line-through">R$ {product.oldPrice.toFixed(2)}</span>
            )}
          </div>

          <div className="flex items-center gap-2 text-sm text-green-600">
            <Check className="h-4 w-4" />
            <span>Em estoque - pronto para envio</span>
          </div>

          <div className="border-t border-b py-4 my-4">
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <div className="flex flex-col gap-4">
            <AddToCartButton product={product} />

            <Button variant="outline">Comprar agora</Button>
          </div>

          <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
            <Truck className="h-4 w-4" />
            <span>Entrega grátis para compras acima de R$ 200,00</span>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Produtos relacionados</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

