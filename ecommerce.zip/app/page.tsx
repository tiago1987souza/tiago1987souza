import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { getFeaturedProducts } from "@/lib/products"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export default async function Home() {
  const featuredProducts = await getFeaturedProducts()

  return (
    <div className="flex flex-col gap-12 pb-8">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Descubra produtos incríveis para o seu dia a dia
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Encontre os melhores produtos com os melhores preços. Entrega rápida e segura para todo o Brasil.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/produtos">
                  <Button size="lg">
                    Explorar produtos
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/categorias">
                  <Button variant="outline" size="lg">
                    Ver categorias
                  </Button>
                </Link>
              </div>
            </div>
            <img
              src="/placeholder.svg?height=550&width=550"
              alt="Produtos em destaque"
              className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last"
            />
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="container px-4 md:px-6">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">Produtos em Destaque</h2>
            <Link href="/produtos" className="text-primary hover:underline flex items-center">
              Ver todos
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="container px-4 md:px-6 py-8 bg-muted rounded-lg">
        <h2 className="text-2xl font-bold tracking-tight mb-6">Navegue por Categorias</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link href="/categorias/eletronicos" className="group">
            <div className="bg-white rounded-lg p-4 shadow-sm transition-all hover:shadow-md">
              <div className="aspect-square bg-secondary rounded-md flex items-center justify-center mb-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-10 w-10 text-primary"
                >
                  <rect width="20" height="14" x="2" y="3" rx="2" />
                  <line x1="8" x2="16" y1="21" y2="21" />
                  <line x1="12" x2="12" y1="17" y2="21" />
                </svg>
              </div>
              <h3 className="font-medium text-center group-hover:text-primary transition-colors">Eletrônicos</h3>
            </div>
          </Link>
          <Link href="/categorias/moda" className="group">
            <div className="bg-white rounded-lg p-4 shadow-sm transition-all hover:shadow-md">
              <div className="aspect-square bg-secondary rounded-md flex items-center justify-center mb-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-10 w-10 text-primary"
                >
                  <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z" />
                  <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9" />
                  <path d="M12 3v6" />
                </svg>
              </div>
              <h3 className="font-medium text-center group-hover:text-primary transition-colors">Moda</h3>
            </div>
          </Link>
          <Link href="/categorias/casa" className="group">
            <div className="bg-white rounded-lg p-4 shadow-sm transition-all hover:shadow-md">
              <div className="aspect-square bg-secondary rounded-md flex items-center justify-center mb-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-10 w-10 text-primary"
                >
                  <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <h3 className="font-medium text-center group-hover:text-primary transition-colors">Casa</h3>
            </div>
          </Link>
          <Link href="/categorias/esportes" className="group">
            <div className="bg-white rounded-lg p-4 shadow-sm transition-all hover:shadow-md">
              <div className="aspect-square bg-secondary rounded-md flex items-center justify-center mb-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-10 w-10 text-primary"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="m4.93 4.93 4.24 4.24" />
                  <path d="m14.83 9.17 4.24-4.24" />
                  <path d="m14.83 14.83 4.24 4.24" />
                  <path d="m9.17 14.83-4.24 4.24" />
                  <circle cx="12" cy="12" r="4" />
                </svg>
              </div>
              <h3 className="font-medium text-center group-hover:text-primary transition-colors">Esportes</h3>
            </div>
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="container px-4 md:px-6">
        <h2 className="text-2xl font-bold tracking-tight mb-6">O que nossos clientes dizem</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <svg
                  key={star}
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  stroke="none"
                  className="h-5 w-5 text-yellow-500"
                >
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                </svg>
              ))}
            </div>
            <p className="text-muted-foreground mb-4">
              "Produtos de excelente qualidade e entrega super rápida. Recomendo a todos!"
            </p>
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-secondary" />
              <div>
                <p className="font-medium">Ana Silva</p>
                <p className="text-sm text-muted-foreground">Cliente desde 2022</p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <svg
                  key={star}
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  stroke="none"
                  className="h-5 w-5 text-yellow-500"
                >
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                </svg>
              ))}
            </div>
            <p className="text-muted-foreground mb-4">
              "Atendimento excepcional e produtos que superam as expectativas. Voltarei com certeza!"
            </p>
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-secondary" />
              <div>
                <p className="font-medium">Carlos Oliveira</p>
                <p className="text-sm text-muted-foreground">Cliente desde 2023</p>
              </div>
            </div>
          </div>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <svg
                  key={star}
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  stroke="none"
                  className="h-5 w-5 text-yellow-500"
                >
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                </svg>
              ))}
            </div>
            <p className="text-muted-foreground mb-4">
              "Preços justos e produtos de alta qualidade. A melhor loja online que já comprei!"
            </p>
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-secondary" />
              <div>
                <p className="font-medium">Mariana Santos</p>
                <p className="text-sm text-muted-foreground">Cliente desde 2021</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

