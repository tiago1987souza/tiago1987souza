import type { Product } from "./types"

// Mock data for products
const products: Product[] = [
  {
    id: "1",
    name: "Smartphone XYZ Pro",
    description:
      "O mais recente smartphone com câmera de alta resolução, processador rápido e bateria de longa duração.",
    price: 1999.99,
    oldPrice: 2499.99,
    image: "/placeholder.svg?height=400&width=400&text=Smartphone",
    category: "eletronicos",
    isNew: true,
    inStock: true,
  },
  {
    id: "2",
    name: "Notebook Ultra Slim",
    description: "Notebook leve e potente com processador de última geração, ideal para trabalho e entretenimento.",
    price: 3499.99,
    image: "/placeholder.svg?height=400&width=400&text=Notebook",
    category: "eletronicos",
    inStock: true,
  },
  {
    id: "3",
    name: "Fones de Ouvido Bluetooth",
    description: "Fones de ouvido sem fio com cancelamento de ruído e bateria de longa duração.",
    price: 299.99,
    oldPrice: 399.99,
    image: "/placeholder.svg?height=400&width=400&text=Fones",
    category: "eletronicos",
    inStock: true,
  },
  {
    id: "4",
    name: "Smartwatch Fitness",
    description: "Relógio inteligente com monitoramento de atividades físicas, batimentos cardíacos e notificações.",
    price: 499.99,
    image: "/placeholder.svg?height=400&width=400&text=Smartwatch",
    category: "eletronicos",
    isNew: true,
    inStock: true,
  },
  {
    id: "5",
    name: "Camiseta Casual",
    description: "Camiseta confortável de algodão, ideal para o dia a dia.",
    price: 59.99,
    image: "/placeholder.svg?height=400&width=400&text=Camiseta",
    category: "moda",
    inStock: true,
  },
  {
    id: "6",
    name: "Tênis Esportivo",
    description: "Tênis leve e confortável, perfeito para corridas e atividades físicas.",
    price: 199.99,
    oldPrice: 249.99,
    image: "/placeholder.svg?height=400&width=400&text=Tênis",
    category: "esportes",
    inStock: true,
  },
  {
    id: "7",
    name: "Cafeteira Elétrica",
    description: "Cafeteira programável com capacidade para 12 xícaras e sistema antigotejamento.",
    price: 149.99,
    image: "/placeholder.svg?height=400&width=400&text=Cafeteira",
    category: "casa",
    inStock: true,
  },
  {
    id: "8",
    name: "Mochila Resistente à Água",
    description: "Mochila espaçosa com compartimento para notebook e resistente à água.",
    price: 129.99,
    image: "/placeholder.svg?height=400&width=400&text=Mochila",
    category: "moda",
    inStock: true,
  },
]

// Function to get all products
export async function getAllProducts(): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products
}

// Function to get featured products
export async function getFeaturedProducts(): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.slice(0, 4)
}

// Function to get a product by ID
export async function getProductById(id: string): Promise<Product | undefined> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.find((product) => product.id === id)
}

// Function to get related products
export async function getRelatedProducts(category: string): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.filter((product) => product.category === category).slice(0, 4)
}

